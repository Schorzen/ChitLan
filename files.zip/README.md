# ChitLan — ChitChat in Island

A community chat website for people currently on Bantayan Island. Plain HTML/CSS/JS, Firebase (Auth + Firestore + optional Storage), hosted on GitHub Pages.

## What's built

- **Google sign-in** + a one-time location check that confirms someone's on Bantayan Island (bounding box over Bantayan, Santa Fe, and Madridejos) — the exact GPS coordinates are never stored, only a yes/no.
- **Home** — daily streak, daily question (admin-set, with a built-in rotating fallback so it's never empty), trending topics, badges, live "who's online" count, in-app notifications.
- **Public Chat** — realtime, auto-prunes down to the most recent 1,000 messages, report/block per message.
- **RandomChat** — queue-based 1:1 matchmaking (no server needed — a Firestore transaction prevents two people claiming the same match), fully ephemeral rooms with no saved history, report/block.
- **Profile** — username, birthday, gender, bio, photo (defaults to the Google account photo; optional custom upload via Firebase Storage).
- **Admin panel** — open reports queue, block/unblock users, set the daily question, manage trending topics, basic stats.

## Project structure

Everything lives in one flat folder on purpose — no subfolders — so it's simple to upload from a phone with no folder-structure surprises:

```
chitlan-web/
  index.html          Sign in + island verification
  home.html            Dashboard
  chat.html             Public Chat
  random.html           RandomChat
  profile.html           Profile
  admin.html              Admin panel (only visible to admins)
  style.css             Shared design system
  firebase-config.js  <- your Firebase keys live here
  auth.js, geofence.js, presence.js, streaks.js, daily-question.js,
  topics.js, notifications.js, chat.js, random-chat.js, profile.js,
  admin.js, nav.js, icons.js, utils.js    (logic, no DOM)
  page-*.js                                (one per HTML page, wires logic to DOM)
  firestore.rules       Security rules — deploy these before going live
```

## Setup

1. **Create a Firebase project** at console.firebase.google.com.
2. **Add a Web app** (the `</>` icon) and copy the config object it gives you into `js/firebase-config.js`.
3. **Authentication** → Sign-in method → enable **Google**.
4. **Firestore Database** → Create database (production mode is fine — `firestore.rules` locks it down). Then paste the contents of `firestore.rules` into the Rules tab and publish.
5. **Authorized domains**: under Authentication → Settings, add your GitHub Pages domain (e.g. `yourname.github.io`) so Google sign-in works once deployed.
6. *(Optional)* **Storage** → Get started, if you want custom profile photo uploads. Skip this and profile photos just use each person's Google account photo.

## Making yourself an admin

There's no self-serve "become admin" button on purpose. After you've signed in once (so your `users/{yourUid}` doc exists):

1. Firebase Console → Firestore Database → `users` collection → find your document.
2. Set `isAdmin` to `true`.
3. Reload the site — an **Admin** tab appears in the bottom nav.

## Deploying to GitHub Pages

1. Push this folder to a GitHub repo.
2. Repo → Settings → Pages → Deploy from branch → pick `main` (or `master`) and `/ (root)`.
3. Your site goes live at `https://yourname.github.io/reponame/`. Add that exact domain to Firebase's Authorized domains (step 5 above) or Google sign-in will fail.

## Known limitations (MVP trade-offs, called out in code comments too)

- **Location check is client-side only.** There's no server verifying GPS, so it's trust-based like most lightweight geofenced apps. A Cloud Function cross-checking IP geography would tighten this later.
- **Online presence** uses a 25-second heartbeat + "active in the last 60 seconds" query rather than Firebase Realtime Database's `onDisconnect()`, since this project only uses Firestore. Closing a tab doesn't instantly drop someone from the count — it just times out within a minute.
- **Message-cap pruning** (keep latest 1,000) runs client-side on whoever sends the message that crosses the limit. A Cloud Function trigger would be more airtight against race conditions, but needs Firebase's paid Blaze plan; this works fine on the free Spark plan.
- **RandomChat cleanup**: if someone closes the tab mid-chat instead of tapping "End chat," the room can linger until the other person reopens the app. A scheduled Cloud Function could sweep these later.
- **Trending Topics** are admin-curated for now rather than auto-detected from chat activity — a nice v2 upgrade once there's real usage data to work with.

## Suggested build order if you're picking this up fresh

1. Firebase project setup (steps above) + confirm Google sign-in works on `index.html`.
2. Walk the flow once end-to-end: sign in → verify location → land on Home.
3. Public Chat (it's the core loop).
4. Profile.
5. RandomChat.
6. Make yourself admin, test the Admin panel, seed a couple of trending topics.
